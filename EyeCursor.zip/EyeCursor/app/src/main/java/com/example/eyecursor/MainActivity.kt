package com.example.eyecursor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Calibration.load(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, 32) }
        root.addView(status)

        fun btn(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        btn("1. Grant camera permission") {
            val p = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
            perms.launch(p.toTypedArray())
        }
        btn("2. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find EyeCursor and turn it on", Toast.LENGTH_LONG).show()
        }
        btn("3. Calibrate (9 dots)") { if (ready()) startActivity(Intent(this, CalibrationActivity::class.java)) }
        btn("4. Start eye control") {
            if (!ready()) return@btn
            if (!Calibration.isReady) { Toast.makeText(this, "Calibrate first", Toast.LENGTH_SHORT).show(); return@btn }
            ContextCompat.startForegroundService(this, Intent(this, GazeService::class.java))
        }
        btn("Stop eye control") { stopService(Intent(this, GazeService::class.java)) }
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun camOk() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun ready(): Boolean {
        if (!camOk()) { Toast.makeText(this, "Grant camera first", Toast.LENGTH_SHORT).show(); return false }
        if (CursorAccessibilityService.instance == null) { Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_SHORT).show(); return false }
        return true
    }

    private fun refresh() {
        fun m(b: Boolean) = if (b) "✅" else "⬜"
        status.text = "${m(camOk())} Camera\n" +
            "${m(CursorAccessibilityService.instance != null)} Accessibility service\n" +
            "${m(Calibration.isReady)} Calibrated"
    }
}
