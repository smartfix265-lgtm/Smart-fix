package com.example.eyecursor

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class CursorAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: CursorAccessibilityService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var cursor: CursorView

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cursor = CursorView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(cursor, lp)
    }

    fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            resources.displayMetrics.let { it.widthPixels to it.heightPixels }
        }

    fun moveTo(x: Float, y: Float) = cursor.set(x, y)
    fun setClosed(c: Boolean) { cursor.closed = c; cursor.postInvalidateOnAnimation() }
    fun hideCursor() { cursor.shown = false; cursor.postInvalidateOnAnimation() }

    fun click(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(g, null, null)
        cursor.flash()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        if (::cursor.isInitialized) runCatching { wm.removeView(cursor) }
        super.onDestroy()
    }
}

/** Lightweight overlay: one circle, redrawn only when the gaze point changes. */
class CursorView(ctx: Context) : View(ctx) {
    @Volatile private var x = -200f
    @Volatile private var y = -200f
    @Volatile var closed = false
    @Volatile var shown = false
    @Volatile private var flashUntil = 0L

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(nx: Float, ny: Float) { x = nx; y = ny; shown = true; postInvalidateOnAnimation() }
    fun flash() { flashUntil = System.currentTimeMillis() + 180; postInvalidateOnAnimation() }

    override fun onDraw(c: Canvas) {
        if (!shown) return
        val flashing = System.currentTimeMillis() < flashUntil
        val color = when {
            flashing -> 0xFF00E676.toInt()
            closed -> 0xFFFF5252.toInt()
            else -> 0xFF00E5FF.toInt()
        }
        ring.color = color; dot.color = color
        c.drawCircle(x, y, if (flashing) 52f else 38f, ring)
        c.drawCircle(x, y, 8f, dot)
        if (flashing) postInvalidateOnAnimation()
    }
}
