package com.example.eyecursor

/** Tune these first if it feels off. */
object Config {
    const val MIN_FRAME_INTERVAL_MS = 40L   // ~25 fps cap: saves battery, plenty for gaze
    const val BLINK_CLOSE = 0.55f           // eyeBlink blendshape score => "closed"
    const val BLINK_OPEN = 0.35f            // must fall below this to count as "open" (hysteresis)
    const val CLICK_MIN_MS = 350L           // shorter = natural blink, ignored
    const val CLICK_MAX_MS = 1200L          // longer = eyes just closed, ignored
    const val SNAP_BACK_MS = 150L           // cursor returns to where you looked before the blink began
    const val FILTER_MIN_CUTOFF = 1.2       // lower = smoother but laggier
    const val FILTER_BETA = 0.02            // higher = more responsive on fast eye moves
}
