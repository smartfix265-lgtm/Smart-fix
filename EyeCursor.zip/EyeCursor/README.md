# EyeCursor — control Android with your eyes

Move your eyes → cursor follows. Deliberate blink (~0.35–1.2 s) → tap.

## Build
1. Open the `EyeCursor` folder in Android Studio (it will generate the Gradle wrapper).
2. Download the model and save it as `app/src/main/assets/face_landmarker.task`:
   https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task
3. Run on a real phone (Android 8+). Emulators can't do this well.

## Use
1. Grant camera → 2. Enable accessibility service (Android 13+ sideloaded apps: App info → ⋮ → "Allow restricted settings" first)
→ 3. Calibrate → 4. Start eye control. Tap the notification to stop.
Recalibrate whenever you change how you hold the phone.

## How it works
- CameraX front camera at ~480x360, latest-frame-only, capped ~25 fps (battery friendly).
- MediaPipe Face Landmarker: 478 landmarks (incl. iris) + blink/eye-look blendshapes, on-device.
- Features (iris position in eye, look up/down, head position) -> screen via ridge regression fitted in calibration.
- One-Euro filter: steady when fixating, fast on saccades.
- Blink click ignores natural blinks (too short); cursor rewinds 150 ms so the click lands where you were looking, not where the closing eyelids dragged it.
- AccessibilityService draws the cursor overlay and injects taps with dispatchGesture.

## Tuning: `Config.kt`
Natural blinks triggering clicks -> raise CLICK_MIN_MS. Clicks hard to trigger -> lower it or BLINK_CLOSE.
Cursor jittery -> lower FILTER_MIN_CUTOFF. Laggy -> raise FILTER_BETA.

## Known limits / next steps
Portrait only. Accuracy is roughly a large button (a few cm), not pixel-precise — a bigger-target UI or zoom helps.
Ideas: dwell-click option, edge zones for Back/Home/scroll, per-user blink calibration, GPU delegate.
Not compiled or tested on a device by me (no Android SDK here) — expect to fix a small thing or two.
