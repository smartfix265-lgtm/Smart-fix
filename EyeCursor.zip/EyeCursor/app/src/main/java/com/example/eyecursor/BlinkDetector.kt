package com.example.eyecursor

/** Turns a per-frame "eyes closed" score into a click only for deliberate, slightly long blinks. */
class BlinkDetector {
    enum class Event { NONE, CLOSED, CLICK, OPENED }

    var isClosed = false
        private set
    private var closedAt = 0L

    fun update(score: Float, now: Long): Event {
        if (!isClosed && score > Config.BLINK_CLOSE) {
            isClosed = true; closedAt = now
            return Event.CLOSED
        }
        if (isClosed && score < Config.BLINK_OPEN) {
            isClosed = false
            val d = now - closedAt
            return if (d in Config.CLICK_MIN_MS..Config.CLICK_MAX_MS) Event.CLICK else Event.OPENED
        }
        return Event.NONE
    }

    fun reset() { isClosed = false }
}
