package com.example.eyecursor

import com.google.mediapipe.tasks.components.containers.Category
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

/**
 * Converts one face-mesh result into a small feature vector:
 * [1, irisX, lookUpMinusDown, irisY, noseX, noseY]
 * (irisX/Y = iris position inside the eye outline, nose = head position in the frame).
 */
object GazeMath {
    private fun alongAxis(lm: List<NormalizedLandmark>, outer: Int, inner: Int, iris: Int): Float {
        val o = lm[outer]; val i = lm[inner]; val p = lm[iris]
        val dx = i.x() - o.x(); val dy = i.y() - o.y()
        val len2 = dx * dx + dy * dy
        if (len2 < 1e-9f) return 0.5f
        return ((p.x() - o.x()) * dx + (p.y() - o.y()) * dy) / len2
    }

    private fun vertical(lm: List<NormalizedLandmark>, up: Int, low: Int, iris: Int): Float {
        val h = lm[low].y() - lm[up].y()
        if (h < 1e-6f) return 0.5f
        return (lm[iris].y() - lm[up].y()) / h
    }

    /** Returns (features, blinkScore 0..1). */
    fun compute(lm: List<NormalizedLandmark>, bs: List<Category>): Pair<FloatArray, Float> {
        var bl = 0f; var br = 0f
        var upL = 0f; var upR = 0f; var dnL = 0f; var dnR = 0f
        for (c in bs) {
            when (c.categoryName()) {
                "eyeBlinkLeft" -> bl = c.score()
                "eyeBlinkRight" -> br = c.score()
                "eyeLookUpLeft" -> upL = c.score()
                "eyeLookUpRight" -> upR = c.score()
                "eyeLookDownLeft" -> dnL = c.score()
                "eyeLookDownRight" -> dnR = c.score()
            }
        }
        val ix = (alongAxis(lm, 33, 133, 468) + alongAxis(lm, 263, 362, 473)) / 2f
        val iy = (vertical(lm, 159, 145, 468) + vertical(lm, 386, 374, 473)) / 2f
        val ud = (upL + upR - dnL - dnR) / 2f
        val nose = lm[1]
        return floatArrayOf(1f, ix, ud, iy, nose.x(), nose.y()) to (bl + br) / 2f
    }
}
