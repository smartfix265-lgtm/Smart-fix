package com.example.eyecursor

import kotlin.math.abs

/** Adaptive low-pass filter: steady when you fixate, fast when you move. */
class OneEuroFilter(
    private val minCutoff: Double = Config.FILTER_MIN_CUTOFF,
    private val beta: Double = Config.FILTER_BETA,
    private val dCutoff: Double = 1.0
) {
    private var xPrev = 0.0
    private var dxPrev = 0.0
    private var tPrev = 0L
    private var init = false

    private fun alpha(cutoff: Double, dt: Double): Double {
        val tau = 1.0 / (2.0 * Math.PI * cutoff)
        return 1.0 / (1.0 + tau / dt)
    }

    fun filter(x: Double, tMs: Long): Double {
        if (!init) { init = true; xPrev = x; tPrev = tMs; return x }
        val dt = (tMs - tPrev).coerceAtLeast(1L) / 1000.0
        tPrev = tMs
        val dx = (x - xPrev) / dt
        val aD = alpha(dCutoff, dt)
        val dxHat = aD * dx + (1 - aD) * dxPrev
        dxPrev = dxHat
        val a = alpha(minCutoff + beta * abs(dxHat), dt)
        xPrev = a * x + (1 - a) * xPrev
        return xPrev
    }

    fun reset() { init = false }
}
