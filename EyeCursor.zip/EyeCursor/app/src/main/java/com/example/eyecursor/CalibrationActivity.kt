package com.example.eyecursor

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class CalibrationActivity : ComponentActivity() {
    private lateinit var view: CalibView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
        view = CalibView(this)
        setContentView(view)

        GazeBus.calibrating = true
        ContextCompat.startForegroundService(this, Intent(this, GazeService::class.java))
        view.post { runCalibration() }
    }

    private fun runCalibration() = lifecycleScope.launch {
        val fr = listOf(0.08f, 0.5f, 0.92f)
        val samples = mutableListOf<FloatArray>()
        val tx = mutableListOf<Float>(); val ty = mutableListOf<Float>()
        delay(1500)                                   // let camera + model warm up
        for (py in fr) for (px in fr) {
            view.target = px to py; view.invalidate()
            delay(800)                                // eyes travel to the dot
            val acc = FloatArray(6); var n = 0
            val end = SystemClock.uptimeMillis() + 1000
            while (n < 15 || SystemClock.uptimeMillis() < end) {
                GazeBus.latest?.let { f -> for (i in f.indices) acc[i] += f[i]; n++ }
                delay(30)
            }
            val mean = FloatArray(6) { acc[it] / n }
            samples += mean; tx += px; ty += py
        }
        val ok = Calibration.fit(samples, tx, ty)
        if (ok) Calibration.save(this@CalibrationActivity)
        Toast.makeText(this@CalibrationActivity, if (ok) "Calibrated ✓" else "Calibration failed, try again", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onDestroy() {
        GazeBus.calibrating = false
        super.onDestroy()
    }
}

class CalibView(ctx: Context) : View(ctx) {
    var target: Pair<Float, Float>? = null
    private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 42f; textAlign = Paint.Align.CENTER }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.BLACK)
        c.drawText("Look at each dot. Keep your head fairly still.", width / 2f, height / 2f + 120f, text)
        target?.let { (fx, fy) ->
            c.drawCircle(fx * width, fy * height, 34f, outer)
            c.drawCircle(fx * width, fy * height, 10f, inner)
        }
    }
}
