package com.example.eyecursor

import android.content.Context
import kotlin.math.abs

/** Ridge-regression map: gaze features -> screen fraction (0..1). Fitted from the 9-point calibration. */
object Calibration {
    private var wx: DoubleArray? = null
    private var wy: DoubleArray? = null
    val isReady get() = wx != null && wy != null

    fun predict(f: FloatArray): Pair<Float, Float>? {
        val a = wx ?: return null
        val b = wy ?: return null
        var x = 0.0; var y = 0.0
        for (i in f.indices) { x += a[i] * f[i]; y += b[i] * f[i] }
        return x.toFloat().coerceIn(0f, 1f) to y.toFloat().coerceIn(0f, 1f)
    }

    fun fit(samples: List<FloatArray>, tx: List<Float>, ty: List<Float>): Boolean {
        val n = samples[0].size
        val a = Array(n) { DoubleArray(n) }
        val bx = DoubleArray(n); val by = DoubleArray(n)
        for (k in samples.indices) {
            val f = samples[k]
            for (i in 0 until n) {
                for (j in 0 until n) a[i][j] += (f[i] * f[j]).toDouble()
                bx[i] += (f[i] * tx[k]).toDouble()
                by[i] += (f[i] * ty[k]).toDouble()
            }
        }
        for (i in 0 until n) a[i][i] += 1e-6
        val sx = solve(a, bx) ?: return false
        val sy = solve(a, by) ?: return false
        wx = sx; wy = sy
        return true
    }

    private fun solve(a0: Array<DoubleArray>, b0: DoubleArray): DoubleArray? {
        val n = b0.size
        val a = Array(n) { a0[it].copyOf() }
        val b = b0.copyOf()
        for (c in 0 until n) {
            var p = c
            for (r in c + 1 until n) if (abs(a[r][c]) > abs(a[p][c])) p = r
            if (abs(a[p][c]) < 1e-12) return null
            val t = a[c]; a[c] = a[p]; a[p] = t
            val tb = b[c]; b[c] = b[p]; b[p] = tb
            for (r in c + 1 until n) {
                val k = a[r][c] / a[c][c]
                for (j in c until n) a[r][j] -= k * a[c][j]
                b[r] -= k * b[c]
            }
        }
        val x = DoubleArray(n)
        for (i in n - 1 downTo 0) {
            var s = b[i]
            for (j in i + 1 until n) s -= a[i][j] * x[j]
            x[i] = s / a[i][i]
        }
        return x
    }

    fun save(ctx: Context) {
        val x = wx ?: return; val y = wy ?: return
        ctx.getSharedPreferences("calib", Context.MODE_PRIVATE).edit()
            .putString("wx", x.joinToString(","))
            .putString("wy", y.joinToString(",")).apply()
    }

    fun load(ctx: Context) {
        if (isReady) return
        val p = ctx.getSharedPreferences("calib", Context.MODE_PRIVATE)
        val sx = p.getString("wx", null) ?: return
        val sy = p.getString("wy", null) ?: return
        wx = sx.split(",").map { it.toDouble() }.toDoubleArray()
        wy = sy.split(",").map { it.toDouble() }.toDoubleArray()
    }
}

/** Shared state between the camera service and the calibration screen. */
object GazeBus {
    @Volatile var latest: FloatArray? = null   // null when no face or eyes closed
    @Volatile var calibrating = false
}
