package com.example.eyecursor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.util.concurrent.Executors

class GazeService : LifecycleService() {
    private val tag = "GazeService"
    private var landmarker: FaceLandmarker? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val blink = BlinkDetector()
    private val fx = OneEuroFilter()
    private val fy = OneEuroFilter()
    private val history = ArrayDeque<DoubleArray>()   // [t, x, y], last ~300 ms
    private var curX = 0f
    private var curY = 0f
    private var lastFrame = 0L
    private var lastTs = 0L

    override fun onCreate() {
        super.onCreate()
        startInForeground()
        Calibration.load(this)
        try {
            landmarker = buildLandmarker()
        } catch (e: Exception) {
            Log.e(tag, "Model load failed", e)
            Toast.makeText(this, "face_landmarker.task missing in assets/ — see README", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        bindCamera()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == "STOP") stopSelf()
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("eye", "Eye control", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, GazeService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "eye")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Eye control is on")
            .setContentText("Tap to stop")
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        else startForeground(1, n)
    }

    private fun buildLandmarker(): FaceLandmarker {
        val base = BaseOptions.builder()
            .setModelAssetPath("face_landmarker.task")
            .setDelegate(Delegate.CPU)      // most compatible; try Delegate.GPU on strong devices
            .build()
        val opts = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumFaces(1)
            .setOutputFaceBlendshapes(true)
            .setMinFaceDetectionConfidence(0.5f)
            .setMinFacePresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { r, i -> onResult(r, i) }
            .setErrorListener { Log.e(tag, "MediaPipe error", it) }
            .build()
        return FaceLandmarker.createFromOptions(this, opts)
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder().setResolutionStrategy(
                        ResolutionStrategy(Size(480, 360), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    ).build()
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(exec) { analyze(it) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(img: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrame < Config.MIN_FRAME_INTERVAL_MS) return
            lastFrame = now
            val ts = maxOf(now, lastTs + 1); lastTs = ts
            val opts = ImageProcessingOptions.builder()
                .setRotationDegrees(img.imageInfo.rotationDegrees).build()
            landmarker?.detectAsync(BitmapImageBuilder(img.toBitmap()).build(), opts, ts)
        } finally {
            img.close()
        }
    }

    private fun onResult(res: FaceLandmarkerResult, input: MPImage) {
        val now = SystemClock.uptimeMillis()
        val lm = res.faceLandmarks().firstOrNull()
        val bs = res.faceBlendshapes().orElse(null)?.firstOrNull()
        if (lm == null || bs == null || lm.size < 478) {       // 478 = mesh + iris
            GazeBus.latest = null; blink.reset(); return
        }
        val svc = CursorAccessibilityService.instance ?: return
        val (feat, blinkScore) = GazeMath.compute(lm, bs)

        when (blink.update(blinkScore, now)) {
            BlinkDetector.Event.CLOSED -> {
                // eyelids drag the iris estimate as they close: rewind to where you were really looking
                history.firstOrNull { it[0] >= now - Config.SNAP_BACK_MS }?.let {
                    curX = it[1].toFloat(); curY = it[2].toFloat(); svc.moveTo(curX, curY)
                }
                svc.setClosed(true)
            }
            BlinkDetector.Event.CLICK -> {
                svc.setClosed(false)
                if (!GazeBus.calibrating) svc.click(curX, curY)
            }
            BlinkDetector.Event.OPENED -> svc.setClosed(false)
            BlinkDetector.Event.NONE -> {}
        }
        if (blink.isClosed) { GazeBus.latest = null; return }   // hold the cursor still while eyes are shut

        GazeBus.latest = feat
        if (GazeBus.calibrating) return
        val p = Calibration.predict(feat) ?: return
        val (w, h) = svc.screenSize()
        curX = fx.filter((p.first * w).toDouble(), now).toFloat()
        curY = fy.filter((p.second * h).toDouble(), now).toFloat()
        history.addLast(doubleArrayOf(now.toDouble(), curX.toDouble(), curY.toDouble()))
        while (history.isNotEmpty() && history.first()[0] < now - 300) history.removeFirst()
        svc.moveTo(curX, curY)
    }

    override fun onDestroy() {
        CursorAccessibilityService.instance?.hideCursor()
        landmarker?.close()
        exec.shutdown()
        super.onDestroy()
    }
}
